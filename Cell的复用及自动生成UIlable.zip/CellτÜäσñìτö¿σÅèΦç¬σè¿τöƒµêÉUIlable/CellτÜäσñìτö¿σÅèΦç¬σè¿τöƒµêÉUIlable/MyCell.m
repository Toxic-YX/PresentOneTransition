//
//  MyCell.m
//  Cell的复用及自动生成UIlable
//
//  Created by 于祥 on 16/5/5.
//  Copyright © 2016年 于祥. All rights reserved.
//

#import "MyCell.h"
#import "MyHeader.h"
@interface MyCell(){
    /**
     *  数组normal情况下UILable
     */
    UILabel * normalLable;
    /**
     *  数组为null时候UILable样式
     */
    UILabel * nullLable;
}

@end
@implementation MyCell
+ (instancetype)cellWithTableView:(UITableView *)tableView{
    static NSString * ID = @"Mycell";
    MyCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[MyCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:ID];
    }
    return cell;
}



- (void)initCreactView:(NSArray *)arr{
    /**
     *  假数据类型
     @[
     @{
     @"productid": @"2",
     @"productname": @"海鲜汇",
     @"count": @"1",
     @"productsumprice": @"1"
     },
     @{
     @"productid": @"2",
     @"productname": @"海鲜汇",
     @"count": @"1",
     @"productsumprice": @"1"
     },
     @{
     @"productid": @"2",
     @"productname": @"海鲜汇",
     @"count": @"1",
     @"productsumprice": @"1"
     }
     ];
     
     从中取出相应的数据一组数组集合,同下面arr
     */
    NSLog(@"arr - %ld",arr.count);
    if (arr == nil) {
        nullLable = [UILabel new];
        nullLable.frame = CGRectMake(0, 0, kScreenWidth , kNullLableHeight);
        nullLable.text = @"系统繁忙,数据暂不存在";
        nullLable.backgroundColor = [UIColor orangeColor];
        [self.contentView addSubview:nullLable];
    }
    else{
        for (int i = 0; i < arr.count; i ++) {
            normalLable = [UILabel new];
            normalLable.frame = CGRectMake(0, 0 + i * (kNormalLableMargin + kNormalLableHeight), kNormalLableWidth, kNormalLableHeight);
            normalLable.backgroundColor = [UIColor greenColor];
            normalLable.text = arr[i];
            [self.contentView addSubview:normalLable];
        }
    }
}

@end
