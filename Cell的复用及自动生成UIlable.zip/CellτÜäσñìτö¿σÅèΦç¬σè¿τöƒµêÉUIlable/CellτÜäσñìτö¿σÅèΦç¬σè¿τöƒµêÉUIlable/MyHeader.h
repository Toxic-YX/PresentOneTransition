//
//  MyHeader.h
//  Cell的复用及自动生成UIlable
//
//  Created by 于祥 on 16/5/5.
//  Copyright © 2016年 于祥. All rights reserved.
//

#ifndef MyHeader_h
#define MyHeader_h

/**
 *   MyCell
 */
// 屏幕宽度
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
// null时候lable的高度
#define kNullLableHeight     40
// normal时候Lable高度
#define kNormalLableWidth    100
#define kNormalLableHeight   40
#define kNormalLableMargin   5


#define UIColorRGBA(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define DEEPREPORT_COLOR UIColorRGBA(204, 227, 227, 1)

#endif /* MyHeader_h */
