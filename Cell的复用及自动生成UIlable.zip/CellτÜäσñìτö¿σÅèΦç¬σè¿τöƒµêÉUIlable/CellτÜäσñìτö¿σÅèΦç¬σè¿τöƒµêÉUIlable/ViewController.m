//
//  ViewController.m
//  Cell的复用及自动生成UIlable
//
//  Created by 于祥 on 16/5/5.
//  Copyright © 2016年 于祥. All rights reserved.
//

#import "ViewController.h"
#import "MyCell.h"
#import "MyHeader.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSString * cellId;
    NSArray *  customMenuArr;
    NSDictionary * customMenuDic;
}
@property(nonatomic, strong)UITableView * tableView;
@end

@implementation ViewController

- (instancetype)init{
    if (self = [super init]) {
        // 初始化数据
        customMenuDic = @{
                          @"productid": @"2",
                          @"productname": @"海鲜汇",
                          @"count": @"1",
                          @"productsumprice": @"1"
                          };
        customMenuArr = @[customMenuDic,customMenuDic,customMenuDic];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor orangeColor];
    [self tableView];
}

#pragma mark UITableViewDelegate

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MyCell * cell = [MyCell  cellWithTableView:tableView];
    if (indexPath.section == 0) {
        customMenuArr = @[@"数据1",@"数据2",@"数据3"]; // 这里先写假数据, 做示范
        [cell initCreactView:customMenuArr];
        cell.backgroundColor = DEEPREPORT_COLOR;
    }
    if (indexPath.section == 1) {
        NSArray * MenuArr = @[@"数据11",@"数据12",@"数据13",@"数据14"]; // 这里先写假数据, 做示范
        [cell initCreactView:MenuArr];
        cell.backgroundColor = [UIColor redColor];
    }
    if (indexPath.section == 2) {
        [cell initCreactView:nil];
        cell.backgroundColor = [UIColor lightGrayColor];
    }
    
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 3 * 50;
    }
    if (indexPath.section == 1) {
        return 4 * 50;
    }
    return 40;
}


- (UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]init];
        _tableView.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight);
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:self.tableView];
    }
    return _tableView;
}
@end
