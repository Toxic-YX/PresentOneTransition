//
//  main.m
//  Cell的复用及自动生成UIlable
//
//  Created by 于祥 on 16/5/5.
//  Copyright © 2016年 于祥. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
