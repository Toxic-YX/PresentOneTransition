//
//  MyCell.h
//  Cell的复用及自动生成UIlable
//
//  Created by 于祥 on 16/5/5.
//  Copyright © 2016年 于祥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell
/**
 *  传数据,根据数据创建相应的UIlable
 */
- (void)initCreactView:(NSArray *)arr;

+ (instancetype)cellWithTableView:(UITableView *)tableView;
@end
