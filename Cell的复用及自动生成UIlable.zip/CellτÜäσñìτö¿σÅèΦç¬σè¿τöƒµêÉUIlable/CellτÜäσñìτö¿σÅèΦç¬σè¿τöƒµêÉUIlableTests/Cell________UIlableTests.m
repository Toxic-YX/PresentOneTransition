//
//  Cell________UIlableTests.m
//  Cell的复用及自动生成UIlableTests
//
//  Created by 于祥 on 16/5/5.
//  Copyright © 2016年 于祥. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Cell________UIlableTests : XCTestCase

@end

@implementation Cell________UIlableTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
